# Memory Directory

This directory contains daily memory files for the Moltbot system.

## Structure
- `YYYY-MM-DD.md` - Daily memory logs
- `heartbeat-state.json` - State tracking for periodic checks

See AGENTS.md for more details on memory management.